package com.example.ludgrow.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ludgrow.data.UserDatabaseHelper
import com.example.ludgrow.ui.theme.telas.HomeScreen
import com.example.ludgrow.ui.theme.telas.LoginScreen
import com.example.ludgrow.ui.theme.telas.RegisterScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val db = UserDatabaseHelper(context)

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            // ao logar com sucesso, vamos para "home" e remover login da back stack
            LoginScreen(db = db, onLoginSuccess = {
                navController.navigate("home") {
                    popUpTo("login") { inclusive = true } // não retorna ao login
                }
            }, onNavigateToRegister = {
                navController.navigate("register")
            })
        }

        composable("register") {
            RegisterScreen(
                db = db,
                onRegisterSuccess = {
                    navController.navigate("login") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onBackToLogin = {
                    navController.navigate("login") {
                        popUpTo("register") { inclusive = true }
                    }
                }
            )
        }

        composable("home") {
            HomeScreen(onLogout = {
                // quando deslogar, volte para a tela de login e limpe a stack
                navController.navigate("login") {
                    popUpTo("home") { inclusive = true }
                }
            })
        }
    }
}
