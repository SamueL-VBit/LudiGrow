package com.example.ludgrow.ui.theme.telas

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ludgrow.data.UserDatabaseHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    db: UserDatabaseHelper,
    onRegisterSuccess: () -> Unit,
    onBackToLogin: () -> Unit // 👈 novo callback
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var userType by remember { mutableStateOf("Pai") }

    var nameError by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Cadastro", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                nameError = it.isBlank()
            },
            label = { Text("Nome") },
            isError = nameError,
            modifier = Modifier.fillMaxWidth()
        )
        if (nameError) Text("Campo obrigatório", color = Color.Red, style = MaterialTheme.typography.labelSmall)

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                emailError = it.isNotBlank() && !android.util.Patterns.EMAIL_ADDRESS.matcher(it).matches()
            },
            label = { Text("Email") },
            isError = emailError,
            modifier = Modifier.fillMaxWidth()
        )
        if (emailError && email.isNotEmpty()) Text("Email inválido", color = Color.Red, style = MaterialTheme.typography.labelSmall)

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                passwordError = it.isNotBlank() && it.length < 6
            },
            label = { Text("Senha") },
            isError = passwordError,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (passwordError && password.isNotEmpty()) Text("Mínimo de 6 caracteres", color = Color.Red, style = MaterialTheme.typography.labelSmall)

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = userType,
            onValueChange = { userType = it },
            label = { Text("Tipo (Pai / AT)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        val isFormValid = name.isNotBlank() && email.isNotBlank() && password.isNotBlank()
                && !nameError && !emailError && !passwordError

        Button(
            onClick = {
                val success = db.registerUser(name.trim(), email.trim(), password, userType)
                if (success) {
                    Toast.makeText(context, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                    onRegisterSuccess()
                } else {
                    Toast.makeText(context, "Erro: email já cadastrado.", Toast.LENGTH_SHORT).show()
                }
            },
            enabled = isFormValid,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cadastrar")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 👇 Botão de voltar para o login
        TextButton(onClick = { onBackToLogin() }) {
            Text("Voltar para Login")
        }
    }
}
