package com.example.ludgrow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.ludgrow.navigation.AppNavigation
import com.example.ludgrow.ui.theme.LudiGrowTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LudiGrowTheme {
                AppNavigation()
            }
        }
    }
}
